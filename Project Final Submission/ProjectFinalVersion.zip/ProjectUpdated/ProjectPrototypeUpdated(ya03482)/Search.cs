﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectPrototypeUpdated_ya03482_
{
    public partial class Search : Form
    {
        public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-7EL8EJFA;Initial Catalog=UniversityManagementSystem;Integrated Security=True");
        public SqlCommand cmd = new SqlCommand();
        public Search()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" && textBox1.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select UserID, Name, Email, ContactNo, Sex, Nationality, Age from Person where Name LIKE '%" + textBox1.Text  + "%';", con);

                DataSet ds = new DataSet();
                sda.Fill(ds, "People Data");
                //sda.Fill(dt);
                dataGridView1.DataSource = ds.Tables["People Data"].DefaultView;
            }

            else if (textBox1.Text == "" && textBox2.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select UserID, Name, Email, ContactNo, Sex, Nationality, Age from Person where UserID LIKE '%" + textBox2.Text + "%';", con);

                DataSet ds = new DataSet();
                sda.Fill(ds, "People Data");
                //sda.Fill(dt);
                dataGridView1.DataSource = ds.Tables["People Data"].DefaultView;
            }
            else if (textBox2.Text != "" && textBox1.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select UserID, Name, Email, ContactNo, Sex, Nationality, Age from Person where Name LIKE '%" + textBox1.Text + "%' and UserID LIKE '%" + textBox2.Text + "%';", con);

                DataSet ds = new DataSet();
                sda.Fill(ds, "People Data");
                //sda.Fill(dt);
                dataGridView1.DataSource = ds.Tables["People Data"].DefaultView;
            }
            else 
            {
                MessageBox.Show("Please Enter a Name or ID to search.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            this.Close();
          
        }
    }
}
