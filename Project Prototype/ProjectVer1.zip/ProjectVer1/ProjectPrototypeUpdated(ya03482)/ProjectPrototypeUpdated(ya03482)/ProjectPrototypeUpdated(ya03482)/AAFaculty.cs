﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectPrototypeUpdated_ya03482_
{
    public partial class AAFaculty : Form
    {
        public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-7EL8EJFA;Initial Catalog=UniversityManagementSystem;Integrated Security=True");
        public SqlCommand cmd = new SqlCommand();
        public AAFaculty(string s)
        {
            InitializeComponent();
            groupBox1.Enabled = false;

            try

            {
                con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Person,Faculty WHERE UserID = FacultyID and UserID = '" + s + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                
                textBox26.Text = dt.Rows[0].ItemArray[0].ToString();
                textBox25.Text = dt.Rows[0].ItemArray[1].ToString();
                textBox3.Text = dt.Rows[0].ItemArray[2].ToString();
                textBox4.Text = dt.Rows[0].ItemArray[3].ToString();
                textBox5.Text = dt.Rows[0].ItemArray[4].ToString();
                textBox6.Text = dt.Rows[0].ItemArray[5].ToString();
                textBox7.Text = dt.Rows[0].ItemArray[7].ToString();
                textBox2.Text = dt.Rows[0].ItemArray[8].ToString();
                textBox1.Text = dt.Rows[0].ItemArray[9].ToString();
                textBox37.Text = dt.Rows[0].ItemArray[11].ToString();
                textBox29.Text = dt.Rows[0].ItemArray[13].ToString();
                textBox28.Text = dt.Rows[0].ItemArray[14].ToString();
                textBox27.Text = dt.Rows[0].ItemArray[15].ToString();
            }




            catch

            {

                MessageBox.Show("Faculty form connection failed");

            }
            finally
            {
                con.Close();
            }


        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox25_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox37_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox28_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox27_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox29_TextChanged(object sender, EventArgs e)
        {

        }

        private void label36_Click(object sender, EventArgs e)
        {

        }
    }
}
