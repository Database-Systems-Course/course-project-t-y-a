﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectPrototypeUpdated_ya03482_
{
    public partial class MSAddDel : Form
    {
        public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-7EL8EJFA;Initial Catalog=UniversityManagementSystem;Integrated Security=True");
        public SqlCommand cmd = new SqlCommand();
        public MSAddDel(string s)
        {
            InitializeComponent();
            groupBox1.Enabled = false;

            try

            {
                con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Person, ROStaff WHERE UserID = ROStaffID and UserID = '" + s + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                textBox47.Text = dt.Rows[0].ItemArray[0].ToString();
                textBox46.Text = dt.Rows[0].ItemArray[1].ToString();
                textBox3.Text = dt.Rows[0].ItemArray[2].ToString();
                textBox4.Text = dt.Rows[0].ItemArray[3].ToString();
                textBox5.Text = dt.Rows[0].ItemArray[4].ToString();
                textBox2.Text = dt.Rows[0].ItemArray[5].ToString();
                textBox1.Text = dt.Rows[0].ItemArray[7].ToString();
                textBox8.Text = dt.Rows[0].ItemArray[8].ToString();
                textBox51.Text = dt.Rows[0].ItemArray[10].ToString();
                textBox48.Text = dt.Rows[0].ItemArray[11].ToString();
                textBox50.Text = dt.Rows[0].ItemArray[12].ToString();
                textBox49.Text = dt.Rows[0].ItemArray[13].ToString();
            }
            catch
            {
                MessageBox.Show("Staff form connection failed");
            }
            finally
            {
                con.Close();

            }
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox47_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox46_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox48_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox50_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox49_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Course WHERE CourseID = '" + textBox17.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if(dt.Rows.Count == 0)
            {
                string prereq = "";
                if (string.IsNullOrEmpty(comboBox3.Text))
                {
                    prereq = "None";
                }
                else
                {
                    prereq = comboBox3.SelectedItem.ToString();
                }
                SqlDataAdapter adapter = new SqlDataAdapter();
                string sql1 = null;
                sql1 = "insert into Course (CourseID, Name, Prerequisite) values ('" + textBox17.Text + " ', '" + textBox16.Text + " ', '" + prereq + " ' );";
                try
                {
                    con.Open();
                    adapter.InsertCommand = new SqlCommand(sql1, con);
                    adapter.InsertCommand.ExecuteNonQuery();
                    MessageBox.Show("Data added into Course Table");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                
                int classes = Int32.Parse(textBox52.Text);

                for (int i = 0; i < classes; i++)
                {
                    string sql2 = null;
                    sql2 = "insert into Class (CourseID, Ne, Prerequisite) values ('" + textBox17.Text + " ', '" + textBox16.Text + " ', '" + prereq + " ' );";
                }

                con.Close(); 
            }
            else
            {
                MessageBox.Show("Course already added");
            }
   
            /**
            string sql2 = null;
            sql2 = "SET IDENTITY_INSERT Student ON insert into Student (Student_Id, Person_login_user_Name, Person_PersonCNIC_No, Department_ID, Current_Year, AdmissionDate, Graduation_Year, CGPA) values('" + Student_Id.Text + " ','" + StUserName.Text + " ', '" + StudentCNIC.Text + " ', '" + StDepartID.Text + " ', '" + StCYear.Text + " ', '" + StAdmDate.Text + " ', '" + StGradYear.Text + " ', NULL) SET IDENTITY_INSERT Student OFF";
            try
            {
                con.Open();
                adapter.InsertCommand = new SqlCommand(sql2, con);
                adapter.InsertCommand.ExecuteNonQuery();
                MessageBox.Show("Data added into Student Table");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();**/
        }

        private void textBox52_TextChanged(object sender, EventArgs e)
        {
            int classes = Int32.Parse(textBox52.Text);
            for (int i = 0; i < classes; i++)
            {
                comboBox4.Items.Add(i+1);
            }
        }
    }
}
