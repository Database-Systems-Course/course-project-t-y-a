﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectPrototypeUpdated_ya03482_
{
    public partial class Form1 : Form
    {
        public string ID = "";
        public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-7EL8EJFA;Initial Catalog=UniversityManagementSystem;Integrated Security=True");
        public SqlCommand cmd = new SqlCommand();
        public Form1(string s)
        {
            InitializeComponent();
            groupBox1.Enabled = false;
            groupBox7.Enabled = false;
            groupBox8.Enabled = false;
            ID = s;
            
            try

            {
                con.Open();
                
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Person,Student WHERE UserID = StudentID and UserID = '" + s + "'", con);
                
                DataTable dt = new DataTable();
                //textBox1.Text = s;
                sda.Fill(dt);
                
                textBox1.Text = dt.Rows[0].ItemArray[0].ToString();
                textBox2.Text = dt.Rows[0].ItemArray[1].ToString();
                textBox3.Text = dt.Rows[0].ItemArray[2].ToString();
                textBox4.Text = dt.Rows[0].ItemArray[3].ToString();
                textBox5.Text = dt.Rows[0].ItemArray[4].ToString();
                textBox6.Text = dt.Rows[0].ItemArray[5].ToString();
                textBox7.Text = dt.Rows[0].ItemArray[7].ToString();
                textBox8.Text = dt.Rows[0].ItemArray[8].ToString();
                textBox9.Text = dt.Rows[0].ItemArray[10].ToString();
                textBox37.Text = dt.Rows[0].ItemArray[11].ToString();
                textBox40.Text = dt.Rows[0].ItemArray[12].ToString();
                textBox39.Text = dt.Rows[0].ItemArray[13].ToString();
                textBox38.Text = dt.Rows[0].ItemArray[14].ToString();
                sda = new SqlDataAdapter("select * from Fees,Student where Student.StudentID = '" + s + "' and Fees.StudentID = '" + s + "';", con);

                dt = new DataTable();
                //textBox1.Text = s;
                sda.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    comboBox6.Items.Add(dt.Rows[i].ItemArray[0].ToString());
                }
                


            }




            catch

            {

                MessageBox.Show("Student form connection failed");

            }
            finally
            {
                con.Close();
            }


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox7_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox8_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("select * from Fees where StudentID = '" + ID + "' and ChallanID = '" + comboBox6.SelectedItem.ToString() + "';", con);

            DataTable dt = new DataTable();
            //textBox1.Text = s;
            sda.Fill(dt);
            textBox34.Text = dt.Rows[0].ItemArray[3].ToString();
            textBox35.Text = dt.Rows[0].ItemArray[4].ToString();
            textBox36.Text = dt.Rows[0].ItemArray[5].ToString();
        }
    }
}
